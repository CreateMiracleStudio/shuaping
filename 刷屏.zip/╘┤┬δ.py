#! python3
# made by BlockChicken

import pyautogui as pg

print("使用须知：\n 1.保证您的输入法为您想刷屏的语言\n 2.若您使用的是中文输入法，保证您想刷屏的内容在全拼打完后按【空格】即可选中\n 3.本程序仅供娱乐，请勿用于商业渠道")
a=0
text=input("请输入您想刷屏的语句的全拼（例：“我爱刷屏”输入“woaishuaping”）")
b=int(input("请输入刷屏的次数（保证您的鼠标在想要刷屏的软件的聊天栏内后按下回车）"))
# 获取聊天栏位置
x, y = pg.position()
while a<b:
    pg.moveTo(x,y)
    pg.click()
    pg.write(text)
    pg.press("space")
    pg.press("enter")
    a+=1

